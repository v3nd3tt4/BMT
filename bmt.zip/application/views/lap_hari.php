<h1>
	Laporan Harian
</h1>
<form action="<?=base_url()?>lap_hari/lihat" method="POST">
	<div class="form-group">
		<label>Tanggal</label>
		<input type="date" class="form-control" style="max-width: 200px" name="tanggal_lap_hari" id="tanggal_lap_hari">
	</div>
	<button type="submit" class="btn btn-primary">Lihat</button>
</form>
<br/><br/><br/>