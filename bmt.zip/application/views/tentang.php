<h1>Sistem Informasi Koperasi </h1>
<p>
	&copy; 2016 All Right Reserved | Created By <a href="https://www.facebook.com/okta.pilopa">Okta Pilopa</a><br/>
	E-mail: pilopaokta@gmail.com<br/>
	Phone Number: 085768551713<br/><br/>
</p>