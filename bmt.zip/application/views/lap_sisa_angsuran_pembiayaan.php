<h3>
laporan Sisa Angsuran Pembiayaan
</h3>
<form action="<?=base_url()?>lap_sisa_angsuran_pembiayaan/lihat" method="POST" id="lap_sisa_angsuran_pembiayaan" class="form-inline">
	<div class="form-group">
		<label>Masukkan Tanggal</label><br/>
		<input type="date" class="form-control" name="tgl_lap_sisa_angsuran_pembiayaan" id="tgl_lap_sisa_angsuran_pembiayaan"/>
	</div>
	<div class="form-group">
		<label style="color: #fff">test</label><br/>
		<button type="submit" class="btn btn-primary">Lihat</button>
	</div>
</form>
<br/><br/>